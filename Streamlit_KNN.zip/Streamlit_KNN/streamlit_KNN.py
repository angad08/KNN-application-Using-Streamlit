import streamlit as st
import numpy as np
import seaborn as sns
import pandas as pd
import random as rd
from matplotlib import pyplot as plt
import plotly.express as px
st.title("Streamlit APP For K-NEAREST NEIGHBORS")
df=pd.read_csv("C:\\Users\\Angat\\Downloads\\KNN_DISTANCES.csv")
mean_frame=pd.DataFrame({"X_AXIS":[df["X_AXIS"].mean()],"Y_AXIS":[df["Y_AXIS"].mean()],"DISTANCE":[0],"CLASS_LABELS":[-1]})
def KNeighbors(K):
    predicted_class=df["CLASS_LABELS"][:K].mode()[0]
    st.write(f"The Datapoint Belongs To {predicted_class}")
    figs=plt.figure(figsize=(15,10))
    plt.style.use("ggplot")
    fig_1=sns.scatterplot(data=mean_frame, x="X_AXIS", y='Y_AXIS', marker="+", ec="face", s=1000)
    fig_2=sns.scatterplot(data=df[:30],x="X_AXIS",y="Y_AXIS",ec="face",s=500,color="#26619c")
    fig_3=sns.scatterplot(data=df[:K],x="X_AXIS",y="Y_AXIS",ec="face",s=750,color="#00a877")
    st.pyplot(figs)
option = st.selectbox(
'SELECT NUMBER OF NEIGBORS',[i for i in range(3,30,2)])
KNeighbors(option)