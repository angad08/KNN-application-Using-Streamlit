from pandas._config.config import options
import streamlit as st
import numpy as np
import seaborn as sns
import pandas as pd
import random as rd
from matplotlib import pyplot as plt
import plotly.express as px
import KNN
np.random.seed(1)
st.title("Streamlit APP For K-NEAREST NEIGHBORS :smile:") 
uploaded_file = st.file_uploader("Choose a excel/csv File")
if uploaded_file is not None:
    extension=str(uploaded_file).split(".")[1].split(",")[0].split("'")[0]
    if extension=="csv":
        df=pd.read_csv(uploaded_file)
    elif extension=="xlsx":
        df=pd.read_excel(uploaded_file) 
    else:
        st.write("Only CSV and XLSX Files allowed:x:") 
try:
    st.dataframe(df)
    oprs = st.selectbox('SELECT OPERATION',["CLASSIFICATION","REGRESSION"])
    X_AXS = float(st.text_input("X_AXIS",0))
    Y_AXS=float(st.text_input("Y_AXIS",0))
    def KNeighbors(K,OPS):
        if OPS=="CLASSIFICATION":
            predicted_class=KNN.K_NEAREST_NEIGBORS(df[["X_AXIS","Y_AXIS"]],df["CLASS"],K,[[X_AXS,Y_AXS]]).KNearestNeighbors()
        else:
            predicted_class=KNN.K_NEAREST_NEIGBORS(df[["X_AXIS","Y_AXIS"]],df["REG"],K,[[X_AXS,Y_AXS]],"R").KNearestNeighbors()
        st.markdown(f"**The Datapoint Belongs To {predicted_class[0][0]}**")
        djs=pd.DataFrame(predicted_class[1],columns=["X_AXIS","Y_AXIS","DISTANCE","PREDICTIONS"])
        st.dataframe(djs[["X_AXIS","Y_AXIS","PREDICTIONS","DISTANCE"]])
        if X_AXS==0 and Y_AXS==0:
            pass
        else:
            figs=plt.figure(figsize=(15,10))
            plt.style.use("ggplot")
            fig_1=sns.scatterplot(data=djs[:30],x="X_AXIS",y="Y_AXIS",s=500)
            fig_2=sns.scatterplot(data=djs[:K],x="X_AXIS",y="Y_AXIS",s=750)
            fig_3=sns.scatterplot(x=[X_AXS],y=[Y_AXS],marker="+",ec="face",s=2000)
            st.pyplot(figs)
    option = st.selectbox('SELECT NUMBER OF NEIGBORS',[i for i in range(3,30,2)])
    KNeighbors(option,oprs)
# else:
#     pass
except:
    pass
