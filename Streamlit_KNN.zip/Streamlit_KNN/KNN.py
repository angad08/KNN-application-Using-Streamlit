import numpy as np
import seaborn as sns
import pandas as pd
import random as rd
from matplotlib import pyplot as plt
import plotly.express as px
import random as rd
class K_NEAREST_NEIGBORS:
    def __init__(self,train_set,labels,K,__center__,ops="C"):
        self.train_set=train_set.values.reshape(-1,2)
        self.labels=labels.values.reshape(-1,1)
        self.K=K
        self.ops=ops
        self.__center__=np.array(__center__)
    def KNearestNeighbors(self):
        try:
            preds=[]
            for i in self.__center__:
                dist = np.sqrt(np.sum((self.train_set - self.__center__)**2, axis=1))
                dist = dist.reshape(-1, 1)
                fitted_set=np.hstack([self.train_set, dist,self.labels])
                neighbors=fitted_set[fitted_set[:,2].argsort()]
                if self.ops=="R":
                    preds.append(neighbors[:self.K][:,-1].mean(axis=0))
                else:
                    preds.append(pd.DataFrame(neighbors[:self.K][:,-1])[0].mode()[0])
            return np.array(preds),neighbors
        except np.AxisError:
            return f"Single Dimension array Not Accepted!!!"
        except TypeError:
            return "Invalid Operation Type!!!"
if __name__=="__main__":
    K_NEAREST_NEIGBORS(train_set,labels,K,__center__,ops="C").KNearestNeighbors()
