import numpy as np
import pandas as pd
import random as rd
import os
arr = np.random.random(1000000).reshape(-1,2)
classes=np.array([rd.choice([0,1,2]) for i in range(arr.shape[0])]).reshape(-1,1)
reg=np.random.random(500000).reshape(-1,1)
dfx=pd.DataFrame(arr,columns=["X_AXIS","Y_AXIS"])
dfy=pd.DataFrame(classes,columns=["CLASS"])
dfz=pd.DataFrame(reg*1000,columns=["REG"])
full_x=pd.concat([dfx,dfy,dfz],axis=1)
path=os.getcwd()
full_x.to_csv(path+"//"+"KNN_DATASET.csv",index=False)
